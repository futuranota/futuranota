Futura Nota — Pack v2 (readable folders)
============================================

Unzip to browse the product like a project on disk.

Structure:
  Brand/object.json       — root brand / object
  Products/…/doc.json   — product docs (+ assets/ for images)
  Content/…/doc.json    — content docs, queries, todos (+ assets/)
  Content/…/nodes/      — nodes linked to that doc
  Nodes/                — nodes tied to the object only
  manifest.json         — schema + counts
  model.json            — full model (paths point to assets/ files)

Re-import the same ZIP in Futura Nota (Import pack).

Note: Knowledge PDFs are listed under source/ with metadata only unless
the file was stored in the app (future versions may include the binary).
